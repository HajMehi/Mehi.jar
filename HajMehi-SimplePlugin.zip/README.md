# SimplePlugin

A small Minecraft Paper plugin by **Haj_Mehi**.

## Features
- Logs a message when the plugin enables.
- Logs a message when the plugin disables.
- Adds `/simpleplugin`, which confirms that the plugin is running.

## Requirements
- Minecraft Paper 1.21.4
- Java 21
- Maven

## Build
Run `mvn package` from this project folder.

The plugin JAR will be created at `target/simpleplugin-1.0.0.jar`.
Copy the JAR into your server's `plugins` folder, then restart the server.

## Command
- `/simpleplugin` — displays a confirmation message.

## Note
Paper calls `onEnable()` when it enables the plugin and `onDisable()` when it disables the plugin during a normal server shutdown. This example does not add in-game commands to unload plugins.
