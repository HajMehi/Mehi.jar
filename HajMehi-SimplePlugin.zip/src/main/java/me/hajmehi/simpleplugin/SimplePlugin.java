package me.hajmehi.simpleplugin;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public final class SimplePlugin extends JavaPlugin {
    @Override
    public void onEnable() {
        getLogger().info("SimplePlugin has been enabled!");
        getServer().getConsoleSender().sendMessage(
                ChatColor.GREEN + "[SimplePlugin] Plugin enabled successfully."
        );
    }

    @Override
    public void onDisable() {
        getLogger().info("SimplePlugin has been disabled.");
        getServer().getConsoleSender().sendMessage(
                ChatColor.RED + "[SimplePlugin] Plugin disabled."
        );
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command,
                             String label, String[] args) {
        if (command.getName().equalsIgnoreCase("simpleplugin")) {
            sender.sendMessage(ChatColor.AQUA + "SimplePlugin is running!");
            return true;
        }
        return false;
    }
}
